import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { theme } from '../styles/theme';
import { SUB_LABELS } from '../lib/constants';

const ORDER = ['microbio', 'chimique', 'metaux', 'emergent', 'confort'];

function colorFor(v) {
  if (v >= 75) return theme.colors.good;
  if (v >= 50) return theme.colors.warn;
  if (v >= 25) return theme.colors.alert;
  return theme.colors.danger;
}

export default function SubScores({ sub }) {
  return (
    <View style={styles.grid}>
      {ORDER.map((k) => {
        const v = sub[k];
        const c = colorFor(v);
        return (
          <View key={k} style={styles.card}>
            <Text style={styles.label}>{SUB_LABELS[k]}</Text>
            <View style={styles.valueRow}>
              <Text style={[styles.value, { color: c }]}>{v}</Text>
              <Text style={styles.outOf}>/100</Text>
            </View>
            <View style={styles.bar}>
              <View style={[styles.barFill, { width: `${v}%`, backgroundColor: c }]} />
            </View>
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 24,
  },
  card: {
    flexBasis: '48%',
    flexGrow: 1,
    padding: 14,
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: theme.radius.md,
    backgroundColor: theme.colors.bgSubtle,
  },
  label: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.8,
    color: theme.colors.textMuted,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  valueRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 4,
    marginBottom: 8,
  },
  value: { fontSize: 26, fontWeight: '700', letterSpacing: -0.5 },
  outOf: { fontSize: 12, color: theme.colors.textMuted, fontWeight: '500' },
  bar: { height: 4, backgroundColor: theme.colors.border, borderRadius: 2, overflow: 'hidden' },
  barFill: { height: '100%', borderRadius: 2 },
});
