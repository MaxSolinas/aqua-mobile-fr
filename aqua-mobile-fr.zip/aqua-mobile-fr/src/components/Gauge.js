import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, Easing } from 'react-native';
import { theme } from '../styles/theme';

/**
 * Jauge circulaire affichant le score 0-100.
 * Utilise des vues circulaires natives (pas de SVG natif pour rester sur Expo Go sans deps lourdes).
 */
export default function Gauge({ score, color, letter, size = 160 }) {
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    anim.setValue(0);
    Animated.timing(anim, {
      toValue: score,
      duration: 1100,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: false,
    }).start();
  }, [score]);

  const animatedNum = anim.interpolate({
    inputRange: [0, 100],
    outputRange: [0, 100],
  });

  const stroke = 10;
  const radius = (size - stroke) / 2;
  const fillSize = size - stroke * 2;

  return (
    <View style={[styles.wrap, { width: size, height: size }]}>
      {/* Track (cercle gris) */}
      <View
        style={[
          styles.ring,
          {
            width: size, height: size, borderRadius: size / 2,
            borderWidth: stroke, borderColor: theme.colors.border,
          },
        ]}
      />
      {/* Cercle de progression simulé par overlay coloré sur l'arc */}
      {/* Pour rester simple en Expo Go sans react-native-svg, on rend un demi-cercle de couleur */}
      <View
        style={[
          styles.ring,
          {
            position: 'absolute',
            width: size, height: size, borderRadius: size / 2,
            borderWidth: stroke,
            borderTopColor: color,
            borderRightColor: score > 25 ? color : 'transparent',
            borderBottomColor: score > 50 ? color : 'transparent',
            borderLeftColor: score > 75 ? color : 'transparent',
            transform: [{ rotate: '-90deg' }],
          },
        ]}
      />
      {/* Centre */}
      <View style={styles.center}>
        <Animated.Text style={styles.num}>
          {anim.interpolate({
            inputRange: [0, 100],
            outputRange: ['0', '100'],
            extrapolate: 'clamp',
          })}
        </Animated.Text>
        <Text style={styles.max}>/ 100</Text>
      </View>
      {/* Lettre */}
      <View style={[styles.letterBubble, { backgroundColor: color }]}>
        <Text style={styles.letterTxt}>{letter}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
  },
  ring: {
    position: 'absolute',
  },
  center: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  num: {
    fontSize: 48,
    fontWeight: '300',
    color: theme.colors.navy,
    letterSpacing: -1.5,
    lineHeight: 50,
  },
  max: {
    fontSize: 11,
    color: theme.colors.textMuted,
    marginTop: 2,
    letterSpacing: 0.5,
  },
  letterBubble: {
    position: 'absolute',
    top: -4, right: -4,
    width: 40, height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.18,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    elevation: 4,
  },
  letterTxt: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
  },
});

/**
 * Variante du Gauge utilisant Animated.Text simple — pour les nombres animés.
 * (le composant principal ci-dessus fait déjà l'animation)
 */
