import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { theme, statusColor } from '../styles/theme';
import { CAT_LABELS } from '../lib/constants';

function fmtNum(v, dec = 2) {
  if (v == null || isNaN(v)) return '—';
  if (v === 0) return '0';
  if (v < 0.001) return v.toExponential(1);
  if (v < 1) return v.toFixed(3);
  if (v < 10) return v.toFixed(dec);
  if (v < 100) return v.toFixed(1);
  return Math.round(v).toString();
}

function limitTxt(p) {
  if (p.limit != null) return `Limite ${fmtNum(p.limit)}`;
  if (p.ref != null) return `Réf. ${fmtNum(p.ref)}`;
  if (p.limitMin != null) return `${p.limitMin}–${p.limitMax}`;
  return '—';
}

export function ParamRow({ param }) {
  return (
    <View style={styles.row}>
      <View style={[styles.dot, { backgroundColor: statusColor(param.status) }]} />
      <View style={styles.info}>
        <Text style={styles.name}>{param.name}</Text>
        <Text style={styles.desc}>
          {param.desc}
          {param.nbDepassement > 0 ? (
            <Text style={styles.depass}>
              {' · '}{param.nbDepassement} dépassement{param.nbDepassement > 1 ? 's' : ''}
            </Text>
          ) : null}
        </Text>
      </View>
      <View style={styles.right}>
        <Text style={styles.value}>{fmtNum(param.moy)} {param.unit}</Text>
        <Text style={styles.limit}>{limitTxt(param)}</Text>
      </View>
    </View>
  );
}

export default function ParamGroup({ catKey, params }) {
  if (!params || !params.length) return null;
  const sorted = [...params].sort((a, b) => {
    const o = { danger: 0, warn: 1, caution: 2, good: 3 };
    return (o[a.status] || 9) - (o[b.status] || 9);
  });
  return (
    <View style={styles.group}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{CAT_LABELS[catKey]}</Text>
        <Text style={styles.headerCount}>
          {sorted.length} paramètre{sorted.length > 1 ? 's' : ''}
        </Text>
      </View>
      {sorted.map((p) => (
        <ParamRow key={p.code} param={p} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  group: {
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: theme.radius.md,
    overflow: 'hidden',
    marginBottom: 14,
    backgroundColor: '#fff',
  },
  header: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: theme.colors.bgSubtle,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerTitle: { fontWeight: '700', fontSize: 14, color: theme.colors.navy },
  headerCount: { fontSize: 11, color: theme.colors.textMuted },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 11,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
    gap: 12,
  },
  dot: { width: 10, height: 10, borderRadius: 5 },
  info: { flex: 1 },
  name: { fontSize: 14, fontWeight: '500', color: theme.colors.text, marginBottom: 2 },
  desc: { fontSize: 11, color: theme.colors.textMuted, lineHeight: 15 },
  depass: { color: theme.colors.danger, fontWeight: '700' },
  right: { alignItems: 'flex-end' },
  value: { fontSize: 13, fontWeight: '600', color: theme.colors.text, fontVariant: ['tabular-nums'] },
  limit: { fontSize: 10, color: theme.colors.textMuted, marginTop: 1 },
});
