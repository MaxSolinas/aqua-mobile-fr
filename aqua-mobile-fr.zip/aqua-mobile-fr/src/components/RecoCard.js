import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { theme } from '../styles/theme';
import { PRODUITS } from '../lib/constants';

const PRIORITY_COLORS = ['#06B6D4', '#0EA5E9', '#6366F1'];

export default function RecoCard({ reco, index, onCta }) {
  const prod = PRODUITS[reco.product];
  if (!prod) return null;
  const color = PRIORITY_COLORS[index] || theme.colors.textMuted;

  return (
    <View style={styles.card}>
      <View style={[styles.priorityBar, { backgroundColor: color }]} />
      <View style={styles.body}>
        <View style={styles.meta}>
          <Text style={styles.family}>{prod.family.toUpperCase()}</Text>
          <Text style={styles.priority}>· Priorité {reco.priority}</Text>
        </View>
        <Text style={styles.name}>{prod.name}</Text>
        <Text style={styles.reason}>{reco.reason}</Text>
        <View style={styles.certs}>
          {prod.certs.map((c) => (
            <View key={c} style={styles.cert}>
              <Text style={styles.certTxt}>{c}</Text>
            </View>
          ))}
        </View>
        <TouchableOpacity style={styles.btn} onPress={onCta} activeOpacity={0.85}>
          <Text style={styles.btnTxt}>Demander un devis →</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: theme.radius.md,
    overflow: 'hidden',
    marginBottom: 10,
    backgroundColor: '#fff',
  },
  priorityBar: { height: 3 },
  body: { padding: 18 },
  meta: { flexDirection: 'row', marginBottom: 6, gap: 8 },
  family: { fontSize: 10, fontWeight: '800', letterSpacing: 0.8, color: theme.colors.navy },
  priority: { fontSize: 10, fontWeight: '600', color: theme.colors.cyanDeep, letterSpacing: 0.6 },
  name: { fontSize: 17, fontWeight: '700', color: theme.colors.navy, marginBottom: 6, letterSpacing: -0.3 },
  reason: { fontSize: 13, color: theme.colors.textSoft, lineHeight: 18, marginBottom: 10 },
  certs: { flexDirection: 'row', flexWrap: 'wrap', gap: 5, marginBottom: 12 },
  cert: {
    paddingHorizontal: 7,
    paddingVertical: 3,
    backgroundColor: theme.colors.bgSubtle,
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: 4,
  },
  certTxt: { fontSize: 9, color: theme.colors.textSoft, fontVariant: ['tabular-nums'] },
  btn: {
    backgroundColor: theme.colors.navy,
    paddingVertical: 12,
    paddingHorizontal: 18,
    borderRadius: theme.radius.sm,
    alignItems: 'center',
  },
  btnTxt: { color: '#fff', fontWeight: '700', fontSize: 13, letterSpacing: 0.2 },
});
