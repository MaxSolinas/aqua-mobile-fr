import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, TextInput,
  StyleSheet, Alert, Linking,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { theme } from '../styles/theme';
import { PRODUITS } from '../lib/constants';

// Leads démo (en prod : Supabase + sync Odoo via n8n)
const DEMO_LEADS = [
  { id: 1, name: 'M. Dupont', email: 'dupont@example.fr', phone: '06 12 34 56 78', commune: 'Nancy', score: 62, status: 'new', date: '2026-05-22' },
  { id: 2, name: 'Mme Martin', email: 'martin@example.fr', phone: '06 98 76 54 32', commune: 'Metz', score: 78, status: 'contacted', date: '2026-05-21' },
  { id: 3, name: 'M. Bernard', email: 'bernard@example.fr', phone: '06 55 44 33 22', commune: 'Pont-à-Mousson', score: 45, status: 'rdv', date: '2026-05-20' },
];

const STATUS_LABELS = {
  new: { label: 'Nouveau', color: '#06B6D4' },
  contacted: { label: 'Contacté', color: '#CA8A04' },
  rdv: { label: 'RDV pris', color: '#9333EA' },
  quote: { label: 'Devis', color: '#0891B2' },
  won: { label: 'Gagné', color: '#16A34A' },
  lost: { label: 'Perdu', color: '#94A3B8' },
};

export default function DealerHomeScreen({ dealer, onLogout, onAnalyzeCommune, setConsumerTab }) {
  const [section, setSection] = useState('home'); // 'home' | 'leads' | 'calc' | 'quote'

  return (
    <ScrollView style={styles.scroll}>
      {/* HEADER */}
      <LinearGradient colors={[theme.colors.navy, theme.colors.navyLight]} style={styles.header}>
        <View style={styles.headerRow}>
          <View style={styles.avatar}>
            <Text style={styles.avatarTxt}>{dealer.avatar}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.dealerName}>{dealer.name}</Text>
            <Text style={styles.dealerRole}>{dealer.dealership} · {dealer.region}</Text>
          </View>
          <TouchableOpacity onPress={() => Alert.alert('Déconnexion', 'Se déconnecter ?', [
            { text: 'Annuler', style: 'cancel' },
            { text: 'Oui', onPress: onLogout, style: 'destructive' },
          ])}>
            <Text style={styles.logoutTxt}>Sortir</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.welcome}>Bonjour {dealer.name.split(' ')[0]},</Text>

        <View style={styles.statsRow}>
          <View style={styles.stat}>
            <Text style={styles.statNum}>3</Text>
            <Text style={styles.statLabel}>Nouveaux leads</Text>
          </View>
          <View style={styles.stat}>
            <Text style={styles.statNum}>12</Text>
            <Text style={styles.statLabel}>Ce mois-ci</Text>
          </View>
          <View style={styles.stat}>
            <Text style={styles.statNum}>34%</Text>
            <Text style={styles.statLabel}>Conversion</Text>
          </View>
        </View>
      </LinearGradient>

      {/* SECTION TABS */}
      <View style={styles.sectionTabs}>
        <SectionTab label="Accueil" active={section === 'home'} onPress={() => setSection('home')} />
        <SectionTab label="Leads" active={section === 'leads'} onPress={() => setSection('leads')} />
        <SectionTab label="Calcul" active={section === 'calc'} onPress={() => setSection('calc')} />
        <SectionTab label="Devis" active={section === 'quote'} onPress={() => setSection('quote')} />
      </View>

      {/* CONTENT */}
      {section === 'home' && (
        <View style={styles.content}>
          <Text style={styles.h2}>Actions rapides</Text>
          <ActionCard
            icon="🔍"
            title="Diagnostic d'une commune"
            sub="Lancez une analyse Hub'Eau pour un prospect."
            onPress={() => setConsumerTab && setConsumerTab()}
          />
          <ActionCard
            icon="📐"
            title="Calculateur dimensionnement"
            sub="Recommandez le bon produit Kinetico selon le foyer."
            onPress={() => setSection('calc')}
          />
          <ActionCard
            icon="📄"
            title="Générer un devis"
            sub="PDF Aqua-branded prêt à envoyer au prospect."
            onPress={() => setSection('quote')}
          />
          <ActionCard
            icon="📋"
            title="Mes leads"
            sub="Suivi et statut des prospects attribués."
            onPress={() => setSection('leads')}
          />
        </View>
      )}

      {section === 'leads' && <LeadsList />}
      {section === 'calc' && <Calculator />}
      {section === 'quote' && <QuoteBuilder dealer={dealer} />}

      <View style={{ height: 24 }} />
    </ScrollView>
  );
}

function SectionTab({ label, active, onPress }) {
  return (
    <TouchableOpacity
      style={[styles.sTab, active && styles.sTabActive]}
      onPress={onPress}
      activeOpacity={0.7}>
      <Text style={[styles.sTabTxt, active && styles.sTabTxtActive]}>{label}</Text>
    </TouchableOpacity>
  );
}

function ActionCard({ icon, title, sub, onPress }) {
  return (
    <TouchableOpacity style={styles.actionCard} onPress={onPress} activeOpacity={0.85}>
      <Text style={styles.actionIcon}>{icon}</Text>
      <View style={{ flex: 1 }}>
        <Text style={styles.actionTitle}>{title}</Text>
        <Text style={styles.actionSub}>{sub}</Text>
      </View>
      <Text style={styles.actionArrow}>›</Text>
    </TouchableOpacity>
  );
}

// ============== LEADS LIST ==============
function LeadsList() {
  return (
    <View style={styles.content}>
      <Text style={styles.h2}>Mes leads ({DEMO_LEADS.length})</Text>
      {DEMO_LEADS.map((l) => {
        const st = STATUS_LABELS[l.status];
        const scoreColor = l.score >= 75 ? theme.colors.good : l.score >= 50 ? theme.colors.warn : theme.colors.alert;
        return (
          <View key={l.id} style={styles.leadCard}>
            <View style={styles.leadRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.leadName}>{l.name}</Text>
                <Text style={styles.leadCommune}>📍 {l.commune}</Text>
              </View>
              <View style={[styles.leadScore, { backgroundColor: scoreColor }]}>
                <Text style={styles.leadScoreTxt}>{l.score}</Text>
              </View>
            </View>
            <View style={styles.leadActions}>
              <TouchableOpacity
                style={styles.leadBtn}
                onPress={() => Linking.openURL(`tel:${l.phone}`)}>
                <Text style={styles.leadBtnTxt}>📞 {l.phone}</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.leadBtn, styles.leadBtnSecondary]}
                onPress={() => Linking.openURL(`mailto:${l.email}`)}>
                <Text style={[styles.leadBtnTxt, styles.leadBtnTxtSecondary]}>✉️ Mail</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.leadFoot}>
              <View style={[styles.statusBadge, { backgroundColor: st.color }]}>
                <Text style={styles.statusTxt}>{st.label}</Text>
              </View>
              <Text style={styles.leadDate}>{l.date}</Text>
            </View>
          </View>
        );
      })}
      <Text style={styles.demoNote}>
        💡 Données démo. En production, synchronisation temps réel avec Odoo CRM via n8n.
      </Text>
    </View>
  );
}

// ============== CALCULATOR ==============
function Calculator() {
  const [persons, setPersons] = useState('4');
  const [hardness, setHardness] = useState('25');
  const [result, setResult] = useState(null);

  function compute() {
    const p = parseInt(persons, 10) || 0;
    const h = parseFloat(hardness) || 0;
    if (p === 0 || h === 0) {
      Alert.alert('Données manquantes', 'Renseigner le foyer et la dureté.');
      return;
    }
    let product = null;
    let reason = '';
    if (h > 35) { product = 'kinetico-q850-od'; reason = `Eau très dure (${h.toFixed(1)} °f). Adoucisseur haute capacité OverDrive recommandé.`; }
    else if (h > 25 || p >= 5) { product = 'kinetico-s250-xp'; reason = `Foyer ${p} personnes, dureté ${h.toFixed(1)} °f. Bi-réservoir S250 XP, 60 L/min, eau adoucie continue.`; }
    else if (h > 15) { product = 'kinetico-s150-xp'; reason = `Eau moyennement dure (${h.toFixed(1)} °f). S150 XP, dimensionnement standard.`; }
    else if (h > 8) { product = 'kinetico-premier-compact'; reason = `Eau douce (${h.toFixed(1)} °f), foyer petit. Compact suffisant.`; }
    else { product = null; reason = 'Eau déjà douce, pas d\'adoucisseur nécessaire. Suggérer filtration charbon pour goût.'; }
    setResult({ product, reason });
  }

  return (
    <View style={styles.content}>
      <Text style={styles.h2}>Calculateur dimensionnement</Text>
      <Text style={styles.helpTxt}>
        Saisir les paramètres du foyer pour obtenir la recommandation produit Kinetico.
      </Text>

      <Text style={styles.label}>NOMBRE DE PERSONNES AU FOYER</Text>
      <TextInput
        style={styles.input}
        value={persons}
        onChangeText={setPersons}
        keyboardType="number-pad"
        placeholder="ex. 4"
      />

      <Text style={styles.label}>DURETÉ DE L'EAU (°f)</Text>
      <TextInput
        style={styles.input}
        value={hardness}
        onChangeText={setHardness}
        keyboardType="decimal-pad"
        placeholder="ex. 25.5"
      />
      <Text style={styles.helpInline}>
        Tip : récupérer depuis le diagnostic Hub'Eau (onglet "Mon eau").
      </Text>

      <TouchableOpacity style={styles.btnPrimary} onPress={compute} activeOpacity={0.85}>
        <Text style={styles.btnPrimaryTxt}>Calculer la recommandation</Text>
      </TouchableOpacity>

      {result && (
        <View style={styles.resultBox}>
          <Text style={styles.resultLabel}>RÉSULTAT</Text>
          {result.product ? (
            <>
              <Text style={styles.resultName}>{PRODUITS[result.product].name}</Text>
              <Text style={styles.resultFamily}>{PRODUITS[result.product].family}</Text>
              <Text style={styles.resultReason}>{result.reason}</Text>
              <View style={styles.certsRow}>
                {PRODUITS[result.product].certs.map(c => (
                  <View key={c} style={styles.certPill}><Text style={styles.certPillTxt}>{c}</Text></View>
                ))}
              </View>
            </>
          ) : (
            <Text style={styles.resultReason}>{result.reason}</Text>
          )}
        </View>
      )}
    </View>
  );
}

// ============== QUOTE BUILDER ==============
function QuoteBuilder({ dealer }) {
  const [client, setClient] = useState('');
  const [address, setAddress] = useState('');
  const [product, setProduct] = useState('kinetico-s250-xp');
  const [price, setPrice] = useState('2890');
  const [generating, setGenerating] = useState(false);

  async function generateQuote() {
    if (!client.trim()) {
      Alert.alert('Champ requis', 'Renseigner le nom du client.');
      return;
    }
    setGenerating(true);
    try {
      const prod = PRODUITS[product];
      const priceNum = parseFloat(price) || 0;
      const tva = priceNum * 0.20;
      const ht = priceNum;
      const ttc = priceNum + tva;
      const date = new Date().toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
      const quoteNum = `AQ-${Date.now().toString().slice(-6)}`;

      const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><style>
        body { font-family: -apple-system, sans-serif; margin: 0; color: #0F172A; }
        .header { padding: 30px 40px; background: linear-gradient(135deg, #0A1F44 0%, #0F2D5C 100%); color: #fff; }
        .brand { font-size: 12px; letter-spacing: 3px; color: #67E8F9; font-weight: 800; }
        .doc-title { font-size: 32px; font-weight: 700; margin-top: 6px; letter-spacing: -0.5px; }
        .quote-meta { margin-top: 14px; font-size: 12px; opacity: 0.8; }
        .container { padding: 30px 40px; }
        .row { display: flex; gap: 40px; margin-bottom: 30px; }
        .col { flex: 1; }
        .col-label { font-size: 10px; font-weight: 800; letter-spacing: 1.5px; color: #94A3B8; margin-bottom: 4px; }
        .col-content { font-size: 13px; line-height: 1.5; }
        table { width: 100%; border-collapse: collapse; margin: 24px 0; }
        th { background: #FBFAF7; padding: 12px; text-align: left; font-size: 11px; color: #475569; font-weight: 700; border-bottom: 2px solid #0A1F44; }
        td { padding: 14px 12px; border-bottom: 1px solid #E5E7EB; font-size: 13px; }
        .totals { width: 280px; margin-left: auto; }
        .totals tr td { padding: 6px 0; border: none; }
        .totals .label { text-align: right; padding-right: 12px; color: #64748B; }
        .totals .value { text-align: right; font-weight: 600; }
        .totals .total { font-size: 16px; font-weight: 700; color: #0A1F44; padding-top: 10px; border-top: 2px solid #0A1F44; }
        .certs { padding: 16px; background: #F0FDFA; border-radius: 8px; margin-top: 20px; font-size: 11px; color: #0F766E; }
        .footer { padding: 24px 40px; background: #FBFAF7; font-size: 10px; color: #64748B; line-height: 1.6; margin-top: 30px; }
      </style></head><body>
        <div class="header">
          <div class="brand">AQUA PURIFY</div>
          <div class="doc-title">Devis ${quoteNum}</div>
          <div class="quote-meta">Émis le ${date} · Valable 30 jours</div>
        </div>
        <div class="container">
          <div class="row">
            <div class="col">
              <div class="col-label">ÉTABLI PAR</div>
              <div class="col-content">
                <strong>${dealer.name}</strong><br>
                ${dealer.dealership}<br>
                ${dealer.region}
              </div>
            </div>
            <div class="col">
              <div class="col-label">CLIENT</div>
              <div class="col-content">
                <strong>${client}</strong><br>
                ${address || ''}
              </div>
            </div>
          </div>

          <table>
            <thead>
              <tr><th>Désignation</th><th style="text-align:right">Qté</th><th style="text-align:right">Prix HT</th></tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <strong>${PRODUITS[product].name}</strong><br>
                  <span style="color:#94A3B8;font-size:11px">${PRODUITS[product].family} · ${PRODUITS[product].desc}</span>
                </td>
                <td style="text-align:right">1</td>
                <td style="text-align:right">${ht.toFixed(2)} €</td>
              </tr>
              <tr>
                <td>Installation + mise en service</td>
                <td style="text-align:right">1</td>
                <td style="text-align:right">Inclus</td>
              </tr>
              <tr>
                <td>Garantie pièces 10 ans (Kinetico)</td>
                <td style="text-align:right">1</td>
                <td style="text-align:right">Incluse</td>
              </tr>
            </tbody>
          </table>

          <table class="totals">
            <tr><td class="label">Total HT</td><td class="value">${ht.toFixed(2)} €</td></tr>
            <tr><td class="label">TVA 20%</td><td class="value">${tva.toFixed(2)} €</td></tr>
            <tr><td class="label total">Total TTC</td><td class="value total">${ttc.toFixed(2)} €</td></tr>
          </table>

          <div class="certs">
            <strong>Certifications produit :</strong> ${PRODUITS[product].certs.join(' · ')}
          </div>
        </div>
        <div class="footer">
          <strong>Conditions :</strong> Devis valable 30 jours à compter de la date d'émission. Acceptation par signature électronique ou retour signé. Installation sous 15 jours ouvrés après acceptation et acompte 30%.<br><br>
          <strong>Aqua Purify S.à r.l.-S</strong> — Luxembourg, distributeur exclusif Kinetico LU, distributeur Viqua FR/LU. Tous les produits proposés disposent d'une ACS valide France (validité prolongée jusqu'au 31/12/2032 sous régime décret 2026-80).
        </div>
      </body></html>`;

      const { uri } = await Print.printToFileAsync({ html });
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(uri, {
          mimeType: 'application/pdf',
          dialogTitle: `Devis ${quoteNum} - ${client}`,
        });
      } else {
        Alert.alert('Devis généré', `Sauvegardé : ${uri}`);
      }
    } catch (e) {
      Alert.alert('Erreur', e.message);
    }
    setGenerating(false);
  }

  return (
    <View style={styles.content}>
      <Text style={styles.h2}>Génération de devis</Text>
      <Text style={styles.helpTxt}>
        Devis PDF Aqua-branded prêt à envoyer au prospect.
      </Text>

      <Text style={styles.label}>NOM DU CLIENT</Text>
      <TextInput
        style={styles.input}
        value={client}
        onChangeText={setClient}
        placeholder="M. Jean Dupont"
        autoCapitalize="words"
      />

      <Text style={styles.label}>ADRESSE</Text>
      <TextInput
        style={[styles.input, { minHeight: 60, textAlignVertical: 'top' }]}
        value={address}
        onChangeText={setAddress}
        placeholder="12 rue de la Paix&#10;54000 Nancy"
        multiline
      />

      <Text style={styles.label}>PRODUIT</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.productScroll}>
        {Object.keys(PRODUITS).map((k) => (
          <TouchableOpacity
            key={k}
            style={[styles.productChip, product === k && styles.productChipActive]}
            onPress={() => setProduct(k)}>
            <Text style={[styles.productChipTxt, product === k && styles.productChipTxtActive]}>
              {PRODUITS[k].name}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <Text style={styles.label}>PRIX HT (€)</Text>
      <TextInput
        style={styles.input}
        value={price}
        onChangeText={setPrice}
        keyboardType="decimal-pad"
      />

      <TouchableOpacity style={styles.btnPrimary} onPress={generateQuote} disabled={generating} activeOpacity={0.85}>
        <Text style={styles.btnPrimaryTxt}>
          {generating ? 'Génération...' : '📄  Générer le devis PDF'}
        </Text>
      </TouchableOpacity>

      <Text style={styles.demoNote}>
        💡 v1 : génération PDF + partage. v2 prévue : signature électronique tactile (build natif EAS requis).
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: theme.colors.bg },
  header: { paddingTop: 24, paddingBottom: 28, paddingHorizontal: 20 },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 18 },
  avatar: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: theme.colors.cyan,
    alignItems: 'center', justifyContent: 'center',
  },
  avatarTxt: { color: theme.colors.navy, fontWeight: '800', fontSize: 14 },
  dealerName: { color: '#fff', fontWeight: '700', fontSize: 15 },
  dealerRole: { color: 'rgba(255,255,255,0.6)', fontSize: 11, marginTop: 2 },
  logoutTxt: { color: theme.colors.cyanLight, fontSize: 12, fontWeight: '600' },
  welcome: { color: '#fff', fontSize: 22, fontWeight: '600', letterSpacing: -0.3, marginBottom: 16 },
  statsRow: { flexDirection: 'row', gap: 8 },
  stat: { flex: 1, padding: 12, backgroundColor: 'rgba(255,255,255,0.08)', borderRadius: 8 },
  statNum: { color: theme.colors.cyanLight, fontSize: 22, fontWeight: '700' },
  statLabel: { color: 'rgba(255,255,255,0.7)', fontSize: 10, marginTop: 2 },

  sectionTabs: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    paddingHorizontal: 8,
    paddingTop: 8,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
    gap: 4,
  },
  sTab: { flex: 1, paddingVertical: 12, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  sTabActive: { borderBottomColor: theme.colors.cyan },
  sTabTxt: { fontSize: 12, color: theme.colors.textMuted, fontWeight: '600' },
  sTabTxtActive: { color: theme.colors.navy, fontWeight: '700' },

  content: { padding: 16 },
  h2: { fontSize: 18, fontWeight: '700', color: theme.colors.navy, marginBottom: 14, letterSpacing: -0.3 },
  helpTxt: { fontSize: 13, color: theme.colors.textSoft, marginBottom: 16, lineHeight: 18 },
  helpInline: { fontSize: 11, color: theme.colors.textMuted, marginTop: -2, marginBottom: 10, fontStyle: 'italic' },
  label: { fontSize: 10, fontWeight: '700', letterSpacing: 1, color: theme.colors.textMuted, marginBottom: 6, marginTop: 12 },
  input: {
    padding: 13,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: theme.radius.md,
    fontSize: 14,
    color: theme.colors.text,
  },
  btnPrimary: {
    backgroundColor: theme.colors.navy,
    paddingVertical: 14,
    borderRadius: theme.radius.md,
    alignItems: 'center',
    marginTop: 20,
  },
  btnPrimaryTxt: { color: '#fff', fontWeight: '700', fontSize: 14 },

  actionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#fff',
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: theme.colors.border,
    marginBottom: 10,
    gap: 14,
  },
  actionIcon: { fontSize: 28 },
  actionTitle: { fontSize: 15, fontWeight: '600', color: theme.colors.navy },
  actionSub: { fontSize: 12, color: theme.colors.textMuted, marginTop: 2 },
  actionArrow: { fontSize: 24, color: theme.colors.textMuted },

  leadCard: {
    padding: 16,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: theme.radius.md,
    marginBottom: 10,
  },
  leadRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  leadName: { fontSize: 15, fontWeight: '600', color: theme.colors.navy },
  leadCommune: { fontSize: 12, color: theme.colors.textMuted, marginTop: 2 },
  leadScore: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  leadScoreTxt: { color: '#fff', fontWeight: '700', fontSize: 14 },
  leadActions: { flexDirection: 'row', gap: 8, marginBottom: 10 },
  leadBtn: {
    flex: 1,
    backgroundColor: theme.colors.navy,
    paddingVertical: 9,
    borderRadius: 6,
    alignItems: 'center',
  },
  leadBtnSecondary: { backgroundColor: '#fff', borderWidth: 1, borderColor: theme.colors.border },
  leadBtnTxt: { color: '#fff', fontWeight: '600', fontSize: 12 },
  leadBtnTxtSecondary: { color: theme.colors.navy },
  leadFoot: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 999 },
  statusTxt: { color: '#fff', fontSize: 10, fontWeight: '700', letterSpacing: 0.3 },
  leadDate: { fontSize: 10, color: theme.colors.textMuted },

  resultBox: {
    marginTop: 20,
    padding: 18,
    backgroundColor: '#F0FDFA',
    borderWidth: 1,
    borderColor: '#CCFBF1',
    borderRadius: theme.radius.md,
  },
  resultLabel: { fontSize: 10, fontWeight: '800', letterSpacing: 1.5, color: theme.colors.cyanDeep, marginBottom: 6 },
  resultName: { fontSize: 18, fontWeight: '700', color: theme.colors.navy, marginBottom: 4, letterSpacing: -0.3 },
  resultFamily: { fontSize: 12, color: theme.colors.cyanDeep, marginBottom: 8 },
  resultReason: { fontSize: 13, color: theme.colors.textSoft, lineHeight: 18, marginBottom: 10 },
  certsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 5 },
  certPill: { paddingHorizontal: 8, paddingVertical: 3, backgroundColor: '#fff', borderRadius: 4, borderWidth: 1, borderColor: theme.colors.border },
  certPillTxt: { fontSize: 10, color: theme.colors.textSoft, fontWeight: '500' },

  productScroll: { flexGrow: 0, marginTop: 4, marginBottom: 4 },
  productChip: {
    paddingHorizontal: 14, paddingVertical: 10,
    backgroundColor: '#fff',
    borderWidth: 1, borderColor: theme.colors.border,
    borderRadius: theme.radius.md,
    marginRight: 6,
  },
  productChipActive: { backgroundColor: theme.colors.navy, borderColor: theme.colors.navy },
  productChipTxt: { fontSize: 12, color: theme.colors.text, fontWeight: '500' },
  productChipTxtActive: { color: '#fff' },

  demoNote: {
    marginTop: 20,
    padding: 12,
    fontSize: 11,
    color: theme.colors.textMuted,
    backgroundColor: '#FFFBEB',
    borderRadius: 8,
    lineHeight: 15,
  },
});
