import React, { useState, useRef } from 'react';
import {
  View, Text, TextInput, ScrollView, TouchableOpacity,
  StyleSheet, Alert, ActivityIndicator, Keyboard,
} from 'react-native';
import * as Location from 'expo-location';
import { LinearGradient } from 'expo-linear-gradient';
import { theme } from '../styles/theme';
import { searchCommunes, reverseGeocode, fetchCommuneByCode } from '../lib/hubeau';

const QUICK = [
  { code: '54395', nom: 'Nancy' },
  { code: '57463', nom: 'Metz' },
  { code: '75056', nom: 'Paris' },
  { code: '13055', nom: 'Marseille' },
  { code: '59350', nom: 'Lille' },
  { code: '69123', nom: 'Lyon' },
];

export default function SearchScreen({ onAnalyze, error }) {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [searching, setSearching] = useState(false);
  const [locating, setLocating] = useState(false);
  const timerRef = useRef(null);

  function debouncedSearch(text) {
    setQuery(text);
    clearTimeout(timerRef.current);
    if (text.trim().length < 2) {
      setSuggestions([]);
      return;
    }
    timerRef.current = setTimeout(async () => {
      setSearching(true);
      try {
        const list = await searchCommunes(text);
        setSuggestions(list);
      } catch (_) {}
      setSearching(false);
    }, 300);
  }

  async function useGps() {
    setLocating(true);
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert(
          'Géolocalisation',
          'Permission refusée. Vous pouvez tapotter le nom de votre commune à la place.',
        );
        setLocating(false);
        return;
      }
      const loc = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      const c = await reverseGeocode(loc.coords.latitude, loc.coords.longitude);
      if (c) {
        Keyboard.dismiss();
        onAnalyze(c);
      } else {
        Alert.alert('Géolocalisation', 'Aucune commune trouvée près de vous.');
      }
    } catch (e) {
      Alert.alert('Géolocalisation', e.message || 'Erreur de localisation.');
    }
    setLocating(false);
  }

  async function handleQuick(c) {
    Keyboard.dismiss();
    const full = await fetchCommuneByCode(c.code);
    onAnalyze(full || c);
  }

  function pickSuggestion(c) {
    setQuery(c.nom);
    setSuggestions([]);
    Keyboard.dismiss();
    onAnalyze(c);
  }

  return (
    <ScrollView
      style={styles.scroll}
      contentContainerStyle={styles.content}
      keyboardShouldPersistTaps="handled">
      {/* HERO header */}
      <LinearGradient
        colors={[theme.colors.navy, theme.colors.navyLight]}
        style={styles.hero}>
        <Text style={styles.brand}>Aqua Purify</Text>
        <Text style={styles.heroTitle}>
          L'eau de votre commune, <Text style={styles.heroTitleItalic}>décodée.</Text>
        </Text>
        <Text style={styles.heroSub}>
          Analyse instantanée de la qualité de votre eau du robinet à partir des données officielles du Ministère de la Santé.
        </Text>
      </LinearGradient>

      {/* Search card */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>💧 Analyser ma commune</Text>

        <View style={styles.inputWrap}>
          <Text style={styles.inputIcon}>🔍</Text>
          <TextInput
            value={query}
            onChangeText={debouncedSearch}
            placeholder="Nom de commune ou code postal"
            placeholderTextColor={theme.colors.textMuted}
            style={styles.input}
            returnKeyType="search"
            autoCorrect={false}
            autoCapitalize="words"
          />
          {searching && (
            <ActivityIndicator
              style={styles.inputSpinner}
              size="small"
              color={theme.colors.cyan}
            />
          )}
        </View>

        {/* Suggestions */}
        {suggestions.length > 0 && (
          <View style={styles.suggestions}>
            {suggestions.map((c, i) => (
              <TouchableOpacity
                key={c.code}
                style={[styles.suggestion, i === suggestions.length - 1 && styles.noBorder]}
                onPress={() => pickSuggestion(c)}
                activeOpacity={0.7}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.sugName}>{c.nom}</Text>
                  <Text style={styles.sugMeta}>
                    {(c.codePostal?.[0] || '') + ' · ' + c.codeDepartement}
                    {c.population ? ` · ${c.population.toLocaleString('fr-FR')} hab.` : ''}
                  </Text>
                </View>
                <Text style={styles.sugCode}>{c.code}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Geoloc button */}
        <TouchableOpacity
          style={styles.gpsBtn}
          onPress={useGps}
          activeOpacity={0.85}
          disabled={locating}>
          {locating ? (
            <ActivityIndicator color={theme.colors.cyanDeep} />
          ) : (
            <>
              <Text style={styles.gpsIcon}>📍</Text>
              <Text style={styles.gpsTxt}>Utiliser ma position</Text>
            </>
          )}
        </TouchableOpacity>

        {/* Quick chips */}
        <Text style={styles.quickLabel}>OU CHOISIR UN EXEMPLE :</Text>
        <View style={styles.quickRow}>
          {QUICK.map((c) => (
            <TouchableOpacity
              key={c.code}
              style={styles.chip}
              onPress={() => handleQuick(c)}
              activeOpacity={0.7}>
              <Text style={styles.chipTxt}>{c.nom}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {error && (
        <View style={styles.errorBox}>
          <Text style={styles.errorTxt}>{error}</Text>
        </View>
      )}

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={styles.footerTxt}>
          Données ARS via Hub'Eau · Ministère de la Santé / SISE-Eaux{'\n'}
          Licence Etalab 2.0 · Aqua Water Score™ v0.1
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: theme.colors.bg },
  content: { paddingBottom: 32 },
  hero: {
    paddingHorizontal: 24,
    paddingTop: 28,
    paddingBottom: 36,
  },
  brand: {
    color: theme.colors.cyanLight,
    fontSize: 12,
    letterSpacing: 2,
    fontWeight: '700',
    marginBottom: 12,
  },
  heroTitle: {
    color: '#fff',
    fontSize: 30,
    fontWeight: '700',
    letterSpacing: -0.8,
    lineHeight: 34,
    marginBottom: 12,
  },
  heroTitleItalic: { fontStyle: 'italic', fontWeight: '400', color: theme.colors.cyanLight },
  heroSub: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: 14,
    lineHeight: 20,
  },
  card: {
    margin: 16,
    marginTop: -20,
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: theme.radius.lg,
    borderWidth: 1,
    borderColor: theme.colors.border,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 24,
    shadowOffset: { width: 0, height: 8 },
    elevation: 3,
  },
  cardTitle: {
    fontSize: 17,
    fontWeight: '700',
    color: theme.colors.navy,
    marginBottom: 16,
    letterSpacing: -0.3,
  },
  inputWrap: { position: 'relative', marginBottom: 10 },
  inputIcon: { position: 'absolute', left: 14, top: 14, fontSize: 16, zIndex: 1 },
  input: {
    paddingVertical: 13,
    paddingHorizontal: 14,
    paddingLeft: 40,
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: theme.radius.md,
    fontSize: 15,
    backgroundColor: theme.colors.bgSubtle,
    color: theme.colors.text,
  },
  inputSpinner: { position: 'absolute', right: 14, top: 14 },
  suggestions: {
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: theme.radius.md,
    marginBottom: 10,
    backgroundColor: '#fff',
  },
  suggestion: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 11,
    paddingHorizontal: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#F1F5F9',
  },
  noBorder: { borderBottomWidth: 0 },
  sugName: { fontSize: 14, fontWeight: '500', color: theme.colors.text },
  sugMeta: { fontSize: 11, color: theme.colors.textMuted, marginTop: 2 },
  sugCode: { fontSize: 11, color: theme.colors.textMuted, fontVariant: ['tabular-nums'] },
  gpsBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    borderRadius: theme.radius.md,
    backgroundColor: '#F0FDFA',
    borderWidth: 1,
    borderColor: '#CCFBF1',
    marginBottom: 18,
  },
  gpsIcon: { fontSize: 16 },
  gpsTxt: { color: theme.colors.cyanDeep, fontWeight: '600', fontSize: 14 },
  quickLabel: {
    fontSize: 10,
    color: theme.colors.textMuted,
    fontWeight: '700',
    letterSpacing: 1,
    marginBottom: 8,
  },
  quickRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 7,
    backgroundColor: theme.colors.bgSubtle,
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: theme.radius.pill,
  },
  chipTxt: { fontSize: 12, color: theme.colors.textSoft, fontWeight: '500' },
  errorBox: {
    marginHorizontal: 16,
    padding: 14,
    borderRadius: theme.radius.md,
    backgroundColor: '#FEF2F2',
    borderWidth: 1,
    borderColor: '#FECACA',
  },
  errorTxt: { color: theme.colors.danger, fontSize: 13 },
  footer: { padding: 20, alignItems: 'center' },
  footerTxt: { fontSize: 10, color: theme.colors.textMuted, textAlign: 'center', lineHeight: 14 },
});
