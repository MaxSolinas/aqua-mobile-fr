import React, { useState, useRef } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, TextInput,
  StyleSheet, Alert, Linking, ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import Gauge from '../components/Gauge';
import SubScores from '../components/SubScores';
import ParamGroup from '../components/ParamGroup';
import RecoCard from '../components/RecoCard';
import { theme } from '../styles/theme';
import { buildVerdict } from '../lib/scoring';
import { buildRecos } from '../lib/recommendations';
import { PRODUITS } from '../lib/constants';

export default function ResultScreen({ commune, score, udi, onBack, dealerMode = false, dealer = null }) {
  const [leadName, setLeadName] = useState(dealerMode ? '' : '');
  const [leadEmail, setLeadEmail] = useState('');
  const [leadPhone, setLeadPhone] = useState('');
  const [leadSent, setLeadSent] = useState(false);
  const [generatingPdf, setGeneratingPdf] = useState(false);
  const leadRef = useRef(null);
  const scrollRef = useRef(null);
  const verdict = buildVerdict(score, score.params, commune);
  const recos = buildRecos(score);

  // Group params by category
  const cats = { microbio: [], chimique: [], metaux: [], emergent: [], confort: [] };
  for (const p of score.params) {
    if (cats[p.cat]) cats[p.cat].push(p);
  }

  let latestDate = score.params.reduce((acc, p) => (!acc || p.latestDate > acc ? p.latestDate : acc), null);
  if (latestDate) {
    latestDate = new Date(latestDate).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
  }
  const totalAnalyses = score.params.reduce((s, p) => s + p.nbAnalyses, 0);

  function scrollToLead() {
    if (leadRef.current && scrollRef.current) {
      leadRef.current.measureLayout(
        scrollRef.current.getInnerViewNode ? scrollRef.current.getInnerViewNode() : scrollRef.current,
        (_x, y) => scrollRef.current.scrollTo({ y: y - 20, animated: true }),
        () => {}
      );
    }
  }

  async function submitLead() {
    if (!leadName.trim() || !leadEmail.trim()) {
      Alert.alert('Champs requis', 'Merci de renseigner votre nom et votre email.');
      return;
    }
    const payload = {
      name: leadName.trim(),
      email: leadEmail.trim(),
      phone: leadPhone.trim() || null,
      commune_insee: commune.code,
      commune_nom: commune.nom,
      score: score.global,
      letter: score.letter,
      recos: recos.map((r) => r.product),
      source: dealerMode ? 'mobile-dealer' : 'mobile-app',
      dealer_id: dealer?.id || null,
      timestamp: new Date().toISOString(),
    };
    // En prod : POST vers webhook n8n configuré dans app.json extra.webhookUrl
    console.log('AQUA LEAD →', payload);
    setLeadSent(true);
  }

  function callAqua() {
    Linking.openURL('tel:+352000000000').catch(() => Alert.alert('Erreur', 'Impossible de lancer l\'appel.'));
  }

  async function generatePdf() {
    setGeneratingPdf(true);
    try {
      const html = buildPdfHtml(commune, score, verdict, recos, dealer);
      const { uri } = await Print.printToFileAsync({ html, base64: false });
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(uri, {
          mimeType: 'application/pdf',
          dialogTitle: `Rapport ${commune.nom}`,
        });
      } else {
        Alert.alert('PDF généré', `Le rapport a été sauvegardé : ${uri}`);
      }
    } catch (e) {
      Alert.alert('Erreur PDF', e.message || 'Impossible de générer le PDF.');
    }
    setGeneratingPdf(false);
  }

  return (
    <ScrollView ref={scrollRef} style={styles.scroll} contentContainerStyle={styles.content}>
      {/* Header avec back button */}
      <View style={styles.topbar}>
        <TouchableOpacity onPress={onBack} style={styles.backBtn} activeOpacity={0.7}>
          <Text style={styles.backTxt}>←  Nouvelle recherche</Text>
        </TouchableOpacity>
      </View>

      {/* HERO */}
      <View style={styles.hero}>
        <Gauge score={score.global} color={score.letterColor} letter={score.letter} size={150} />
        <View style={styles.heroInfo}>
          <Text style={styles.communeName}>{commune.nom}</Text>
          <View style={styles.metaRow}>
            <Text style={styles.metaItem}>📍 {commune.codeDepartement || ''} · {commune.code}</Text>
          </View>
          {udi?.length > 0 && (
            <Text style={styles.metaItem}>💧 {udi.length} UDI{udi.length > 1 ? 's' : ''}</Text>
          )}
          {latestDate && (
            <Text style={styles.metaItem}>📅 Dernier prél. : {latestDate}</Text>
          )}
          <Text style={styles.metaItem}>📊 {score.params.length} paramètres · {totalAnalyses} analyses</Text>
          <Text style={[styles.descTag, { color: score.letterColor }]}>
            {score.letterDesc}
          </Text>
        </View>
      </View>

      <Text style={styles.verdict}>{verdict}</Text>

      {/* SUB SCORES */}
      <SubScores sub={score.sub} />

      {/* ACTIONS */}
      <View style={styles.actions}>
        <TouchableOpacity style={styles.actionBtn} onPress={generatePdf} disabled={generatingPdf} activeOpacity={0.85}>
          {generatingPdf ? (
            <ActivityIndicator size="small" color={theme.colors.navy} />
          ) : (
            <Text style={styles.actionBtnTxt}>📄  Télécharger PDF</Text>
          )}
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionBtn} onPress={callAqua} activeOpacity={0.85}>
          <Text style={styles.actionBtnTxt}>📞  Appeler un expert</Text>
        </TouchableOpacity>
      </View>

      {/* PARAMETERS */}
      <Text style={styles.sectionTitle}>Détail des paramètres mesurés</Text>
      {Object.keys(cats).map((k) => (
        <ParamGroup key={k} catKey={k} params={cats[k]} />
      ))}

      {/* RECOS */}
      {recos.length > 0 ? (
        <>
          <Text style={styles.sectionTitle}>→ Solutions recommandées</Text>
          {recos.map((r, i) => (
            <RecoCard key={r.product} reco={r} index={i} onCta={scrollToLead} />
          ))}
        </>
      ) : (
        <View style={styles.allGood}>
          <Text style={styles.allGoodTitle}>Votre eau est globalement excellente</Text>
          <Text style={styles.allGoodTxt}>
            Aucune intervention prioritaire identifiée d'après les analyses Hub'Eau disponibles.
          </Text>
        </View>
      )}

      {/* LEAD FORM */}
      <View ref={leadRef} collapsable={false}>
        <LinearGradient
          colors={[theme.colors.navy, theme.colors.navyLight]}
          style={styles.leadCard}>
          {leadSent ? (
            <View style={styles.success}>
              <Text style={styles.successIcon}>✓</Text>
              <Text style={styles.successTxt}>
                Merci {leadName}, votre demande est enregistrée. Un conseiller Aqua Purify vous recontacte sous 24 h ouvrées.
              </Text>
            </View>
          ) : (
            <>
              <Text style={styles.leadTitle}>
                {dealerMode ? 'Enregistrer ce lead' : 'Un expert vous rappelle'}
              </Text>
              <Text style={styles.leadSub}>
                {dealerMode
                  ? 'Saisir les coordonnées du prospect pour création automatique dans Odoo CRM.'
                  : 'Diagnostic gratuit à domicile · Test physique de votre eau · Devis détaillé sous 48 h.'}
              </Text>
              <TextInput
                value={leadName}
                onChangeText={setLeadName}
                placeholder="Votre nom"
                placeholderTextColor="rgba(255,255,255,0.4)"
                style={styles.leadInput}
                autoCapitalize="words"
              />
              <TextInput
                value={leadEmail}
                onChangeText={setLeadEmail}
                placeholder="Votre e-mail"
                placeholderTextColor="rgba(255,255,255,0.4)"
                style={styles.leadInput}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />
              <TextInput
                value={leadPhone}
                onChangeText={setLeadPhone}
                placeholder="Téléphone (optionnel)"
                placeholderTextColor="rgba(255,255,255,0.4)"
                style={styles.leadInput}
                keyboardType="phone-pad"
              />
              <TouchableOpacity style={styles.leadBtn} onPress={submitLead} activeOpacity={0.85}>
                <Text style={styles.leadBtnTxt}>
                  {dealerMode ? 'Créer le lead →' : 'Être contacté →'}
                </Text>
              </TouchableOpacity>
              <Text style={styles.disclaimer}>
                Les recommandations affichées sont des suggestions techniques générées à partir des données ARS / Hub'Eau et ne se substituent pas à un diagnostic professionnel. Données traitées conformément au RGPD.
              </Text>
            </>
          )}
        </LinearGradient>
      </View>

      <View style={{ height: 24 }} />
    </ScrollView>
  );
}

// ============== PDF HTML TEMPLATE ==============
function buildPdfHtml(commune, score, verdict, recos, dealer) {
  const cleanVerdict = verdict.replace(/<[^>]+>/g, '');
  const sortedParams = [...score.params].sort((a, b) => {
    const o = { danger: 0, warn: 1, caution: 2, good: 3 };
    return (o[a.status] || 9) - (o[b.status] || 9);
  });
  function fmt(v) {
    if (v == null) return '—';
    if (v < 0.001) return v.toExponential(1);
    if (v < 1) return v.toFixed(3);
    if (v < 10) return v.toFixed(2);
    return v.toFixed(1);
  }
  function statusLabel(s) {
    return { good: 'OK', caution: 'À surveiller', warn: 'Limite', danger: 'Dépassement' }[s] || '—';
  }
  function statusColorPdf(s) {
    return { good: '#16A34A', caution: '#CA8A04', warn: '#EA580C', danger: '#DC2626' }[s] || '#94A3B8';
  }

  const recoHtml = recos.map((r) => {
    const p = PRODUITS[r.product];
    return `
      <div class="reco">
        <div class="reco-fam">${p.family.toUpperCase()} · Priorité ${r.priority}</div>
        <div class="reco-name">${p.name}</div>
        <div class="reco-reason">${r.reason}</div>
        <div class="reco-certs">${p.certs.join(' · ')}</div>
      </div>`;
  }).join('');

  const paramsHtml = sortedParams.map(p => `
    <tr>
      <td>${p.name}</td>
      <td class="num">${fmt(p.moy)} ${p.unit}</td>
      <td class="num">${fmt(p.max)} ${p.unit}</td>
      <td class="num">${p.limit ?? p.ref ?? (p.limitMin != null ? `${p.limitMin}-${p.limitMax}` : '—')}</td>
      <td><span class="badge" style="background:${statusColorPdf(p.status)}">${statusLabel(p.status)}</span></td>
    </tr>`).join('');

  return `<!DOCTYPE html><html><head><meta charset="UTF-8"><style>
    body { font-family: -apple-system, sans-serif; margin: 0; color: #0F172A; font-size: 11px; }
    .header { background: #0A1F44; color: #fff; padding: 24px 32px; }
    .brand { color: #67E8F9; font-size: 11px; letter-spacing: 2px; font-weight: 800; }
    .brand-sub { color: rgba(255,255,255,0.7); font-size: 10px; margin-top: 4px; }
    .commune { font-size: 28px; font-weight: 700; margin-top: 16px; letter-spacing: -0.5px; }
    .container { padding: 24px 32px; }
    .score-row { display: flex; gap: 24px; align-items: flex-start; margin-bottom: 28px; padding-bottom: 24px; border-bottom: 1px solid #E5E7EB; }
    .score-box { width: 130px; height: 130px; border-radius: 14px; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #fff; }
    .score-num { font-size: 48px; font-weight: 700; line-height: 1; }
    .score-out { font-size: 10px; opacity: 0.8; }
    .score-letter { font-size: 22px; font-weight: 700; margin-top: 8px; }
    .verdict-block { flex: 1; padding-top: 8px; }
    .verdict-title { font-size: 16px; font-weight: 700; color: #0A1F44; margin-bottom: 8px; }
    .verdict { color: #475569; line-height: 1.5; }
    .meta-row { margin-top: 12px; font-size: 10px; color: #94A3B8; }
    .section { margin-top: 24px; }
    .section-title { font-size: 12px; font-weight: 800; letter-spacing: 1px; color: #0A1F44; margin-bottom: 12px; }
    .subs { display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; }
    .sub { padding: 10px; background: #FBFAF7; border-radius: 6px; border: 1px solid #E5E7EB; }
    .sub-label { font-size: 9px; font-weight: 700; color: #94A3B8; text-transform: uppercase; letter-spacing: 0.8px; }
    .sub-val { font-size: 20px; font-weight: 700; margin-top: 4px; }
    table { width: 100%; border-collapse: collapse; margin-top: 4px; }
    th { background: #FBFAF7; padding: 8px 10px; text-align: left; font-size: 10px; color: #64748B; font-weight: 700; border-bottom: 1px solid #E5E7EB; }
    td { padding: 6px 10px; font-size: 10px; border-bottom: 1px solid #F1F5F9; }
    td.num { font-family: monospace; }
    .badge { display: inline-block; padding: 2px 6px; border-radius: 3px; color: #fff; font-size: 9px; font-weight: 600; }
    .reco { padding: 14px 16px; border: 1px solid #E5E7EB; border-radius: 8px; margin-bottom: 8px; background: #fff; }
    .reco-fam { font-size: 9px; color: #0891B2; font-weight: 800; letter-spacing: 1px; }
    .reco-name { font-size: 14px; font-weight: 700; color: #0A1F44; margin: 4px 0 6px; }
    .reco-reason { color: #475569; font-size: 10px; line-height: 1.4; margin-bottom: 6px; }
    .reco-certs { font-family: monospace; font-size: 9px; color: #94A3B8; }
    .footer { margin-top: 32px; padding: 16px 32px; background: #FBFAF7; font-size: 9px; color: #94A3B8; line-height: 1.5; }
    ${dealer ? '.dealer-stamp { background: #F0FDFA; border: 1px solid #06B6D4; padding: 10px 14px; border-radius: 6px; margin-bottom: 16px; font-size: 11px; color: #0891B2; }' : ''}
  </style></head>
  <body>
    <div class="header">
      <div class="brand">AQUA PURIFY</div>
      <div class="brand-sub">Rapport de qualité de l'eau · Émis le ${new Date().toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}</div>
      <div class="commune">${commune.nom}</div>
    </div>
    <div class="container">
      ${dealer ? `<div class="dealer-stamp">Établi par <strong>${dealer.name}</strong> · ${dealer.dealership || 'Réseau Premier Cercle'}</div>` : ''}
      <div class="score-row">
        <div class="score-box" style="background:${score.letterColor}">
          <div class="score-num">${score.global}</div>
          <div class="score-out">/ 100</div>
          <div class="score-letter">${score.letter}</div>
        </div>
        <div class="verdict-block">
          <div class="verdict-title">Score Aqua Water™ : ${score.letterDesc}</div>
          <div class="verdict">${cleanVerdict}</div>
          <div class="meta-row">Commune ${commune.code} · ${score.params.length} paramètres analysés</div>
        </div>
      </div>
      <div class="section">
        <div class="section-title">SOUS-SCORES</div>
        <div class="subs">
          <div class="sub"><div class="sub-label">Microbio.</div><div class="sub-val">${score.sub.microbio}</div></div>
          <div class="sub"><div class="sub-label">Chimique</div><div class="sub-val">${score.sub.chimique}</div></div>
          <div class="sub"><div class="sub-label">Métaux</div><div class="sub-val">${score.sub.metaux}</div></div>
          <div class="sub"><div class="sub-label">Émergents</div><div class="sub-val">${score.sub.emergent}</div></div>
          <div class="sub"><div class="sub-label">Confort</div><div class="sub-val">${score.sub.confort}</div></div>
        </div>
      </div>
      <div class="section">
        <div class="section-title">PARAMÈTRES MESURÉS</div>
        <table>
          <thead><tr><th>Paramètre</th><th>Moyenne</th><th>Maximum</th><th>Limite/Réf.</th><th>Statut</th></tr></thead>
          <tbody>${paramsHtml}</tbody>
        </table>
      </div>
      ${recos.length > 0 ? `<div class="section"><div class="section-title">SOLUTIONS RECOMMANDÉES</div>${recoHtml}</div>` : ''}
    </div>
    <div class="footer">
      <strong>Méthodologie :</strong> pondération limites × 3, références × 1, microbio = veto. Sous-scores : Microbio (30%), Chimique (30%), Métaux (15%), Confort (15%), Émergents (10%).<br><br>
      <strong>Disclaimer :</strong> Rapport généré automatiquement à partir des données publiques Hub'Eau (Min. Santé / SISE-Eaux, Licence Etalab 2.0). Seuils issus de l'arrêté du 11 janvier 2007 modifié, transposant la directive UE 2020/2184. Les recommandations sont des suggestions techniques et ne constituent pas un diagnostic professionnel. Aqua Purify ne saurait être tenu responsable d'une décision prise sur la seule base de cet outil.
    </div>
  </body></html>`;
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: theme.colors.bg },
  content: { paddingHorizontal: 16, paddingBottom: 20 },
  topbar: { paddingVertical: 12 },
  backBtn: { alignSelf: 'flex-start' },
  backTxt: { color: theme.colors.cyanDeep, fontSize: 14, fontWeight: '600' },
  hero: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
    marginBottom: 20,
  },
  heroInfo: { flex: 1 },
  communeName: { fontSize: 22, fontWeight: '700', color: theme.colors.navy, letterSpacing: -0.5, marginBottom: 6 },
  metaRow: { marginBottom: 2 },
  metaItem: { fontSize: 11, color: theme.colors.textSoft, marginBottom: 2, lineHeight: 16 },
  descTag: { fontSize: 13, fontWeight: '700', marginTop: 8 },
  verdict: { fontSize: 14, color: theme.colors.text, lineHeight: 21, marginBottom: 24 },
  actions: { flexDirection: 'row', gap: 10, marginBottom: 24 },
  actionBtn: {
    flex: 1,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: theme.radius.md,
    alignItems: 'center',
  },
  actionBtnTxt: { fontSize: 13, fontWeight: '600', color: theme.colors.navy },
  sectionTitle: { fontSize: 16, fontWeight: '700', color: theme.colors.navy, marginTop: 12, marginBottom: 12, letterSpacing: -0.3 },
  allGood: {
    padding: 18,
    backgroundColor: '#F0FDF4',
    borderWidth: 1,
    borderColor: '#BBF7D0',
    borderRadius: theme.radius.md,
    marginTop: 8,
  },
  allGoodTitle: { fontWeight: '700', fontSize: 15, color: '#15803D', marginBottom: 4 },
  allGoodTxt: { fontSize: 12, color: '#166534', lineHeight: 17 },
  leadCard: {
    marginTop: 20,
    padding: 22,
    borderRadius: theme.radius.md,
    overflow: 'hidden',
  },
  leadTitle: { color: '#fff', fontSize: 19, fontWeight: '700', letterSpacing: -0.3, marginBottom: 6 },
  leadSub: { color: 'rgba(255,255,255,0.7)', fontSize: 12, lineHeight: 17, marginBottom: 14 },
  leadInput: {
    padding: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
    borderRadius: theme.radius.sm,
    color: '#fff',
    fontSize: 14,
    marginBottom: 8,
  },
  leadBtn: {
    backgroundColor: theme.colors.cyan,
    paddingVertical: 13,
    borderRadius: theme.radius.sm,
    alignItems: 'center',
    marginTop: 6,
  },
  leadBtnTxt: { color: theme.colors.navy, fontWeight: '700', fontSize: 14 },
  disclaimer: { fontSize: 10, color: 'rgba(255,255,255,0.5)', lineHeight: 14, marginTop: 14 },
  success: { alignItems: 'center', paddingVertical: 12 },
  successIcon: { color: '#22C55E', fontSize: 36, marginBottom: 8 },
  successTxt: { color: '#fff', textAlign: 'center', fontSize: 14, lineHeight: 20 },
});
