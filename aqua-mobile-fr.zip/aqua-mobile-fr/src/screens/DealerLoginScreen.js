import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, Alert, ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { theme } from '../styles/theme';

// Comptes de démo locaux (en prod : auth Supabase + RLS)
const DEMO_ACCOUNTS = {
  'max@aquapurify.lu': {
    password: 'demo',
    profile: {
      id: 'd-001',
      name: 'Maxime Solinas',
      dealership: 'Aqua Purify (siège)',
      role: 'admin',
      region: 'Luxembourg + France',
      avatar: 'MS',
    },
  },
  'dealer@premier.fr': {
    password: 'demo',
    profile: {
      id: 'd-042',
      name: 'Premier Cercle (démo)',
      dealership: 'Réseau Premier Cercle',
      role: 'dealer',
      region: 'Lorraine',
      avatar: 'PC',
    },
  },
};

export default function DealerLoginScreen({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  async function tryLogin() {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Champs requis', 'Saisir email et mot de passe.');
      return;
    }
    setLoading(true);
    // Simule un appel auth
    await new Promise((r) => setTimeout(r, 600));
    const acc = DEMO_ACCOUNTS[email.trim().toLowerCase()];
    if (acc && acc.password === password) {
      onLogin(acc.profile);
    } else {
      Alert.alert(
        'Connexion refusée',
        'Identifiants invalides.\n\nDémo : max@aquapurify.lu / demo\nou dealer@premier.fr / demo',
      );
    }
    setLoading(false);
  }

  function fillDemo() {
    setEmail('max@aquapurify.lu');
    setPassword('demo');
  }

  return (
    <ScrollView style={styles.scroll} keyboardShouldPersistTaps="handled">
      <LinearGradient colors={[theme.colors.navy, theme.colors.navyLight]} style={styles.hero}>
        <Text style={styles.brand}>AQUA PURIFY</Text>
        <Text style={styles.title}>Espace pro</Text>
        <Text style={styles.subtitle}>
          Réservé aux revendeurs du{'\n'}réseau Premier Cercle.
        </Text>
      </LinearGradient>

      <View style={styles.card}>
        <Text style={styles.label}>EMAIL PROFESSIONNEL</Text>
        <TextInput
          value={email}
          onChangeText={setEmail}
          placeholder="dealer@example.fr"
          placeholderTextColor={theme.colors.textMuted}
          style={styles.input}
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
        />

        <Text style={styles.label}>MOT DE PASSE</Text>
        <TextInput
          value={password}
          onChangeText={setPassword}
          placeholder="••••••••"
          placeholderTextColor={theme.colors.textMuted}
          style={styles.input}
          secureTextEntry
        />

        <TouchableOpacity style={styles.btn} onPress={tryLogin} activeOpacity={0.85} disabled={loading}>
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.btnTxt}>Se connecter</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity style={styles.demoBtn} onPress={fillDemo} activeOpacity={0.6}>
          <Text style={styles.demoTxt}>Utiliser un compte de démo</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.info}>
        <Text style={styles.infoTitle}>💼 Fonctionnalités pro</Text>
        <Text style={styles.infoItem}>· Diagnostic terrain géolocalisé</Text>
        <Text style={styles.infoItem}>· Calculateur de dimensionnement</Text>
        <Text style={styles.infoItem}>· Génération de devis PDF</Text>
        <Text style={styles.infoItem}>· Saisie de leads avec sync Odoo</Text>
        <Text style={styles.infoItem}>· Tableau de bord activité</Text>
      </View>

      <Text style={styles.footer}>
        Pas encore membre du réseau Premier Cercle ?{'\n'}Contactez contact@aquapurify.lu
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: theme.colors.bg },
  hero: { padding: 28, paddingTop: 32 },
  brand: { color: theme.colors.cyanLight, fontSize: 11, letterSpacing: 2, fontWeight: '800' },
  title: { color: '#fff', fontSize: 30, fontWeight: '700', letterSpacing: -0.8, marginTop: 8 },
  subtitle: { color: 'rgba(255,255,255,0.7)', fontSize: 14, lineHeight: 20, marginTop: 8 },
  card: {
    margin: 16,
    marginTop: -16,
    padding: 22,
    backgroundColor: '#fff',
    borderRadius: theme.radius.lg,
    borderWidth: 1,
    borderColor: theme.colors.border,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 24,
    elevation: 3,
  },
  label: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1,
    color: theme.colors.textMuted,
    marginBottom: 6,
    marginTop: 8,
  },
  input: {
    padding: 13,
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: theme.radius.md,
    fontSize: 14,
    color: theme.colors.text,
    backgroundColor: theme.colors.bgSubtle,
    marginBottom: 8,
  },
  btn: {
    backgroundColor: theme.colors.navy,
    paddingVertical: 14,
    borderRadius: theme.radius.md,
    alignItems: 'center',
    marginTop: 16,
  },
  btnTxt: { color: '#fff', fontWeight: '700', fontSize: 14 },
  demoBtn: { alignItems: 'center', paddingVertical: 12 },
  demoTxt: { color: theme.colors.cyanDeep, fontSize: 12, fontWeight: '600' },
  info: {
    margin: 16,
    padding: 18,
    backgroundColor: '#F0FDFA',
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: '#CCFBF1',
  },
  infoTitle: { fontWeight: '700', color: theme.colors.cyanDeep, marginBottom: 8, fontSize: 14 },
  infoItem: { fontSize: 12, color: '#0F766E', lineHeight: 20 },
  footer: {
    fontSize: 11,
    color: theme.colors.textMuted,
    textAlign: 'center',
    lineHeight: 16,
    margin: 24,
  },
});
