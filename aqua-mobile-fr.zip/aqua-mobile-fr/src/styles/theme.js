// Design tokens — alignés sur le widget web aqua-water-score-fr
export const theme = {
  colors: {
    bg: '#FBFAF7',
    bgWhite: '#FFFFFF',
    bgSubtle: '#FBFAF7',
    border: '#E5E7EB',
    borderStrong: '#CBD5E1',
    text: '#0F172A',
    textSoft: '#475569',
    textMuted: '#94A3B8',
    navy: '#0A1F44',
    navyLight: '#0F2D5C',
    cyan: '#06B6D4',
    cyanDeep: '#0891B2',
    cyanLight: '#67E8F9',
    good: '#16A34A',
    goodSoft: '#65A30D',
    warn: '#CA8A04',
    alert: '#EA580C',
    danger: '#DC2626',
    success: '#22C55E',
  },
  radius: {
    sm: 8,
    md: 12,
    lg: 16,
    xl: 20,
    pill: 999,
  },
  spacing: {
    xs: 4,
    sm: 8,
    md: 12,
    lg: 16,
    xl: 24,
    xxl: 32,
  },
  font: {
    family: undefined, // System default (San Francisco / Roboto)
    sizes: {
      xs: 11,
      sm: 12,
      base: 14,
      md: 16,
      lg: 18,
      xl: 22,
      xxl: 28,
      huge: 48,
    },
  },
};

export function statusColor(status) {
  return {
    good: theme.colors.good,
    caution: theme.colors.warn,
    warn: theme.colors.alert,
    danger: theme.colors.danger,
  }[status] || theme.colors.textMuted;
}
